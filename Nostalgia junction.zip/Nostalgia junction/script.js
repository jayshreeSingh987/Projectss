// script.js

// Add event listener to the navigation bar icon
document.querySelector('.bar_icon').addEventListener('click', () => {
    // Toggle the navigation menu
    document.querySelector('.navigation').classList.toggle('active');
  });
  
  // Add event listener to the order form submit button
  document.querySelector('.order_btn').addEventListener('click', (e) => {
    e.preventDefault();
    // Get the form data
    const formData = new FormData(document.querySelector('form'));
    // Send the form data to the server (you'll need to implement this part)
    console.log(formData);
  });
  
  // Add event listener to the feature section images
  document.querySelectorAll('.feature img').forEach((img) => {
    img.addEventListener('click', () => {
      // Open a modal window with the image (you'll need to implement this part)
      console.log('Image clicked!');
    });
  });